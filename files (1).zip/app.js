// ---------- DATA: yahan apne providers add karo ----------
const CATEGORIES = [
  {id:'doctor', name:'Doctor', icon:'🩺'},
  {id:'dentist', name:'Dentist', icon:'🦷'},
  {id:'mech', name:'Mechanical Engineer', icon:'⚙️'},
  {id:'civil', name:'Civil Engineer', icon:'🏗️'},
  {id:'car', name:'Car/Bike Mechanic', icon:'🔧'},
  {id:'elec', name:'Electrician', icon:'💡'},
  {id:'plumb', name:'Plumber', icon:'🚰'},
  {id:'ac', name:'AC Repair', icon:'❄️'},
  {id:'lawyer', name:'Vakeel', icon:'⚖️'},
  {id:'tutor', name:'Tutor', icon:'📚'}
];
const PROVIDERS = [
  {id:1,name:'Dr. Anita Verma',cat:'doctor',spec:'Physician, MBBS MD',city:'Kanpur',fee:500,rating:4.8,exp:14,open:true,tags:['Bukhar','Diabetes','BP']},
  {id:2,name:'Dr. Rohit Mishra',cat:'doctor',spec:'Bachchon ke doctor',city:'Lucknow',fee:600,rating:4.6,exp:9,open:true,tags:['Pediatric','Vaccine']},
  {id:3,name:'Dr. Sana Khan',cat:'dentist',spec:'BDS, Root canal expert',city:'Kanpur',fee:400,rating:4.7,exp:8,open:false,tags:['Root canal','Braces']},
  {id:4,name:'Er. Vikas Gupta',cat:'mech',spec:'B.Tech Mechanical, machine design',city:'Kanpur',fee:800,rating:4.5,exp:11,open:true,tags:['CAD','Plant maintenance','Consulting']},
  {id:5,name:'Er. Pooja Singh',cat:'mech',spec:'HVAC aur thermal systems',city:'Delhi',fee:1200,rating:4.9,exp:13,open:true,tags:['HVAC','Energy audit']},
  {id:6,name:'Er. Manoj Yadav',cat:'civil',spec:'Ghar ka naksha aur structure',city:'Lucknow',fee:700,rating:4.4,exp:10,open:true,tags:['Naksha','Site visit']},
  {id:7,name:'Raju Auto Works',cat:'car',spec:'Car aur bike servicing',city:'Kanpur',fee:300,rating:4.3,exp:16,open:true,tags:['Service','Engine','Tyre']},
  {id:8,name:'Shiv Garage',cat:'car',spec:'Bike specialist',city:'Delhi',fee:250,rating:4.5,exp:7,open:false,tags:['Bike','Puncture']},
  {id:9,name:'Imran Electricals',cat:'elec',spec:'Ghar ki wiring aur repair',city:'Kanpur',fee:200,rating:4.6,exp:12,open:true,tags:['Wiring','Inverter','Fan']},
  {id:10,name:'Suresh Plumbing',cat:'plumb',spec:'Leakage, tanki, bathroom fitting',city:'Lucknow',fee:250,rating:4.2,exp:9,open:true,tags:['Leakage','Fitting']},
  {id:11,name:'CoolCare AC Service',cat:'ac',spec:'AC install, gas, repair',city:'Delhi',fee:450,rating:4.7,exp:6,open:true,tags:['Split AC','Gas refill']},
  {id:12,name:'Adv. Neha Tripathi',cat:'lawyer',spec:'Property aur family cases',city:'Kanpur',fee:1000,rating:4.6,exp:12,open:true,tags:['Property','Family']},
  {id:13,name:'Amit Sir',cat:'tutor',spec:'Maths aur Physics, class 9-12',city:'Kanpur',fee:350,rating:4.8,exp:8,open:true,tags:['JEE','Board']}
];

// ---------- STATE ----------
const $ = s => document.querySelector(s);
const state = {cat:'all', q:'', city:'Sabhi shehar', sort:'rating'};
const load = () => { try { return JSON.parse(localStorage.getItem('sevak_bookings')) || []; } catch { return []; } };
const save = b => { try { localStorage.setItem('sevak_bookings', JSON.stringify(b)); } catch {} };
let bookings = load();
const catOf = id => CATEGORIES.find(c => c.id === id);

// ---------- RENDER ----------
function init(){
  const cities = ['Sabhi shehar', ...new Set(PROVIDERS.map(p => p.city))];
  $('#city').innerHTML = cities.map(c => `<option>${c}</option>`).join('');
  renderChips(); render(); renderBookings();
  $('#q').oninput = e => { state.q = e.target.value.toLowerCase(); render(); };
  $('#city').onchange = e => { state.city = e.target.value; render(); };
  $('#sort').onchange = e => { state.sort = e.target.value; render(); };
  $('#tabBrowse').onclick = () => showTab('browse');
  $('#tabBookings').onclick = () => showTab('bookings');
  $('#close').onclick = closeModal;
  $('#modal').onclick = e => { if (e.target.id === 'modal') closeModal(); };
  document.onkeydown = e => { if (e.key === 'Escape') closeModal(); };
}
function showTab(t){
  $('#browse').hidden = t !== 'browse'; $('#bookings').hidden = t !== 'bookings';
  $('#tabBrowse').classList.toggle('on', t === 'browse');
  $('#tabBookings').classList.toggle('on', t === 'bookings');
}
function renderChips(){
  const all = [{id:'all', name:'Sabhi', icon:'✨'}, ...CATEGORIES];
  $('#chips').innerHTML = all.map(c =>
    `<button class="chip ${state.cat === c.id ? 'on' : ''}" data-c="${c.id}">${c.icon} ${c.name}</button>`).join('');
  document.querySelectorAll('.chip').forEach(b => b.onclick = () => { state.cat = b.dataset.c; renderChips(); render(); });
}
function filtered(){
  let list = PROVIDERS.filter(p =>
    (state.cat === 'all' || p.cat === state.cat) &&
    (state.city === 'Sabhi shehar' || p.city === state.city) &&
    (!state.q || [p.name, p.spec, catOf(p.cat).name, ...p.tags].join(' ').toLowerCase().includes(state.q)));
  const s = {rating:(a,b)=>b.rating-a.rating, priceAsc:(a,b)=>a.fee-b.fee, exp:(a,b)=>b.exp-a.exp}[state.sort];
  return list.sort(s);
}
function render(){
  const list = filtered();
  $('#result').textContent = `${list.length} option mile`;
  $('#grid').innerHTML = list.length ? list.map(p => `
    <button class="card" data-id="${p.id}">
      <div class="row"><div class="avatar">${catOf(p.cat).icon}</div>
        <div><h3>${p.name}</h3><div class="muted">${p.spec}</div></div></div>
      <div class="meta"><span class="rate">★ ${p.rating}</span><span>${p.exp} saal ka experience</span></div>
      <div class="meta"><span>${p.city}</span><span class="fee">₹${p.fee}</span></div>
      <div class="${p.open ? 'open' : 'closed'}">${p.open ? 'Abhi available' : 'Abhi band'}</div>
    </button>`).join('') : '<p class="muted">Kuch nahi mila. Doosra shehar ya category try karo.</p>';
  document.querySelectorAll('.card').forEach(c => c.onclick = () => openProvider(+c.dataset.id));
}

// ---------- BOOKING ----------
function openProvider(id){
  const p = PROVIDERS.find(x => x.id === id);
  const today = new Date().toISOString().split('T')[0];
  $('#sheetBody').innerHTML = `
    <h2>${p.name}</h2>
    <div class="muted">${catOf(p.cat).name} · ${p.city}</div>
    <p>${p.spec}. ${p.exp} saal ka experience, rating ★ ${p.rating}. Fees ₹${p.fee}.</p>
    <div class="tags">${p.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
    <label for="bName">Aapka naam</label><input id="bName" autocomplete="name">
    <label for="bPhone">Phone number</label><input id="bPhone" type="tel" inputmode="numeric" maxlength="10" placeholder="10 digit">
    <label for="bDate">Tareekh</label><input id="bDate" type="date" min="${today}" value="${today}">
    <label for="bTime">Samay</label>
    <select id="bTime">${['10:00','11:00','12:00','14:00','16:00','18:00'].map(t=>`<option>${t}</option>`).join('')}</select>
    <label for="bNote">Kya problem hai? (optional)</label><textarea id="bNote" rows="2"></textarea>
    <p id="err" class="closed"></p>
    <button class="btn" id="confirm">Booking confirm karo</button>`;
  $('#confirm').onclick = () => confirmBooking(p);
  $('#modal').hidden = false;
}
function confirmBooking(p){
  const name = $('#bName').value.trim(), phone = $('#bPhone').value.trim();
  if (!name) return $('#err').textContent = 'Apna naam likho.';
  if (!/^[6-9]\d{9}$/.test(phone)) return $('#err').textContent = 'Sahi 10 digit ka mobile number likho.';
  bookings.unshift({id:Date.now(), pid:p.id, name, phone, date:$('#bDate').value, time:$('#bTime').value, note:$('#bNote').value.trim()});
  save(bookings); renderBookings(); closeModal(); toast('Booking ho gayi ✔');
}
function renderBookings(){
  $('#count').hidden = !bookings.length; $('#count').textContent = bookings.length;
  $('#bookList').innerHTML = bookings.length ? bookings.map(b => {
    const p = PROVIDERS.find(x => x.id === b.pid);
    return `<div class="bk"><div><strong>${p.name}</strong><div class="muted">${b.date}, ${b.time} · ₹${p.fee}</div>
      <div class="muted">${b.name} (${b.phone})${b.note ? ' · ' + b.note.replace(/</g,'&lt;') : ''}</div></div>
      <button class="btn ghost" data-b="${b.id}">Cancel</button></div>`;
  }).join('') : '<p class="muted">Abhi koi booking nahi hai. "Khojo" tab se kisi ko book karo.</p>';
  document.querySelectorAll('[data-b]').forEach(x => x.onclick = () => {
    bookings = bookings.filter(b => b.id !== +x.dataset.b); save(bookings); renderBookings(); toast('Booking cancel ho gayi');
  });
}
function closeModal(){ $('#modal').hidden = true; }
function toast(m){ const t = $('#toast'); t.textContent = m; t.hidden = false; setTimeout(() => t.hidden = true, 2200); }
init();
