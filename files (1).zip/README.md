# Sevak

Zomato jaisa app, lekin restaurant ki jagah **doctor, dentist, mechanical/civil engineer, mechanic, electrician, plumber, vakeel aur tutor** ke liye.

## Features
- Category, shehar aur search se filter
- Rating, fees ya experience se sort
- Provider ki detail aur appointment booking
- "Meri bookings" tab (browser mein save hoti hain)
- Mobile friendly, dark mode support

## Chalane ka tarika
Koi install nahi chahiye. `index.html` ko browser mein kholo.

## GitHub par daalna
```bash
git init
git add .
git commit -m "Sevak: first version"
git branch -M main
git remote add origin https://github.com/<tumhara-username>/sevak.git
git push -u origin main
```
Phir repo mein **Settings > Pages > Branch: main** chuno. App `https://<username>.github.io/sevak/` par live ho jayega.

## Apna data add karna
`app.js` ke upar `PROVIDERS` aur `CATEGORIES` list mein naye entries daalo.

## Aage kya banana hai
- Asli backend aur database (Firebase ya Supabase)
- Login aur provider ka apna dashboard
- Online payment aur map par location
- Mobile app version (Flutter ya React Native)

*Abhi ka data sirf demo hai.*
